import { Directive, ElementRef, OnDestroy, OnInit } from '@angular/core';

/**
 * Adds the `.reveal` class to the host element and toggles `.visible` once
 * it scrolls into view, using a single per-element IntersectionObserver.
 *
 * Usage: <div appReveal>...</div>
 *
 * This replaces the previous approach of collecting a QueryList of
 * #revealEl template refs in the page component and observing them all in
 * ngAfterViewInit — that logic was duplicated across every page. As a
 * directive it's reusable across Home, Pairing, or any future page without
 * copy-pasting the observer setup.
 */
@Directive({
  selector: '[appReveal]',
  standalone: true,
  host: { class: 'reveal' },
})
export class RevealDirective implements OnInit, OnDestroy {
  private observer?: IntersectionObserver;

  constructor(private el: ElementRef<HTMLElement>) {}

  ngOnInit(): void {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            this.observer?.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    this.observer.observe(this.el.nativeElement);
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}
