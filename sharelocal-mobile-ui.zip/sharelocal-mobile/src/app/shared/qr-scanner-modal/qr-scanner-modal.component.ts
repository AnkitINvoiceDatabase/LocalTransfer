import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { PairingService } from '../../core/services/pairing.service';

/**
 * Reusable "scan a QR code" modal.
 *
 * Tries the device camera first (getUserMedia). If that's unavailable or
 * denied, falls back to a file-upload input so the user can pick a photo of
 * the QR code instead — matching the two paths in the original page.
 *
 * NOTE: actual QR *decoding* (reading the pixels into a token) is not wired
 * up yet — this is intentionally mocked via PairingService, per the current
 * "no API integration yet" phase. The real implementation should either:
 *   - integrate the `html5-qrcode` library against a plain <div> (not the
 *     <video> element directly — that was a bug in the original prototype), or
 *   - decode frames manually via a canvas + a JS QR-decoding library.
 */
@Component({
  selector: 'app-qr-scanner-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './qr-scanner-modal.component.html',
  styleUrl: './qr-scanner-modal.component.scss',
})
export class QrScannerModalComponent implements OnChanges, OnDestroy {
  @Input() isOpen = false;
  @Output() closed = new EventEmitter<void>();
  @Output() scanned = new EventEmitter<string>();

  @ViewChild('cameraPreview') cameraPreviewRef?: ElementRef<HTMLVideoElement>;

  cameraAvailable = true;
  statusMessage = '';
  private mediaStream?: MediaStream;

  constructor(private pairingService: PairingService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['isOpen']) {
      if (this.isOpen) {
        // wait a tick so the <video> element exists in the DOM before we attach the stream
        setTimeout(() => this.startCamera(), 0);
      } else {
        this.stopCamera();
      }
    }
  }

  ngOnDestroy(): void {
    this.stopCamera();
  }

  close(): void {
    this.stopCamera();
    this.closed.emit();
  }

  private async startCamera(): Promise<void> {
    this.statusMessage = 'Requesting camera access…';

    if (!navigator.mediaDevices?.getUserMedia) {
      this.cameraAvailable = false;
      this.statusMessage = 'Camera not supported on this device.';
      return;
    }

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      this.cameraAvailable = true;
      this.statusMessage = 'Point your camera at the QR code.';

      const video = this.cameraPreviewRef?.nativeElement;
      if (video) {
        video.srcObject = this.mediaStream;
      }
    } catch (err) {
      this.cameraAvailable = false;
      this.statusMessage = 'Camera unavailable — upload a QR image instead.';
    }
  }

  private stopCamera(): void {
    this.mediaStream?.getTracks().forEach((track) => track.stop());
    this.mediaStream = undefined;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.statusMessage = 'Reading QR image…';
    this.pairingService.uploadQrImage(file).subscribe((result) => {
      if (result.success) {
        this.statusMessage = 'QR code recognized.';
        this.scanned.emit(result.qrText);
      } else {
        this.statusMessage = result.message || 'Could not read QR code from that image.';
      }
    });
    input.value = '';
  }
}
