import { Injectable, computed, signal } from '@angular/core';
import { SelectedFile, formatBytes, typeForFileName } from '../models/file-transfer.model';

/**
 * Holds the "files selected for sending" state so it can be shared between
 * the upload dropzone, the selected-files panel, and (later) the pairing /
 * progress screens — without prop-drilling through component inputs.
 *
 * Pure client-side state for now. No HTTP calls live here; wiring this up to
 * a real transfer/session API is a future step (see PairingService).
 */
@Injectable({ providedIn: 'root' })
export class FileTransferService {
  private readonly _files = signal<SelectedFile[]>([]);
  private nextId = 1;

  readonly files = this._files.asReadonly();

  readonly totalCount = computed(() => this._files().length);

  readonly totalSizeLabel = computed(() => {
    const totalBytes = this._files().reduce((sum, f) => sum + f.sizeBytes, 0);
    return formatBytes(totalBytes);
  });

  addFiles(fileList: FileList | File[] | null): void {
    if (!fileList) return;
    const incoming = Array.from(fileList).map((file) => this.toSelectedFile(file));
    this._files.update((current) => [...current, ...incoming]);
  }

  /** Seed with demo data so the UI isn't empty on first load (matches original design). */
  seedDemoFiles(demo: Array<{ name: string; sizeLabel: string; sizeBytes: number }>): void {
    const seeded = demo.map((d) => {
      const t = typeForFileName(d.name);
      return {
        id: this.nextId++,
        name: d.name,
        sizeLabel: d.sizeLabel,
        sizeBytes: d.sizeBytes,
        cls: t.cls,
        icon: t.icon,
      };
    });
    this._files.set(seeded);
  }

  removeFile(id: number): void {
    // mark as "removing" first so the template can animate it out, then
    // actually splice it after the CSS transition finishes.
    this._files.update((list) => list.map((f) => (f.id === id ? { ...f, removing: true } : f)));
    setTimeout(() => {
      this._files.update((list) => list.filter((f) => f.id !== id));
    }, 220);
  }

  clear(): void {
    this._files.set([]);
  }

  private toSelectedFile(file: File): SelectedFile {
    const t = typeForFileName(file.name);
    return {
      id: this.nextId++,
      name: file.name,
      sizeLabel: formatBytes(file.size),
      sizeBytes: file.size,
      cls: t.cls,
      icon: t.icon,
    };
  }
}
