import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

export interface GenerateQrResult {
  /** Object URL / data URL the <img> can point to directly. */
  imageUrl: string;
  /** The raw token/text encoded in the QR, useful for debugging in dev. */
  token: string;
}

export interface ConnectResult {
  connected: boolean;
}

export interface ScanUploadResult {
  success: boolean;
  qrText: string;
  message?: string;
}

/**
 * All methods here are MOCKED for now, per project instructions
 * ("ignore the .NET API, we'll integrate it later").
 *
 * Each method documents the real endpoint it will eventually call so wiring
 * up HttpClient later is a small, contained change:
 *
 *   generateQr()   -> GET  /api/pair/generate
 *   connect(token) -> POST /api/pair/connect
 *   uploadQrImage()-> POST /Scan/Upload
 */
@Injectable({ providedIn: 'root' })
export class PairingService {
  /**
   * TODO(api): replace with
   *   this.http.get('/api/pair/generate', { responseType: 'blob' })
   * and convert the blob to an object URL.
   */
  generateQr(): Observable<GenerateQrResult> {
    const mockToken = 'mock-pair-token-' + Math.random().toString(36).slice(2, 10);
    const imageUrl = this.buildPlaceholderQrDataUrl(mockToken);
    return of({ imageUrl, token: mockToken }).pipe(delay(400));
  }

  /**
   * TODO(api): replace with
   *   this.http.post('/api/pair/connect', { token, deviceName, deviceType })
   */
  connect(token: string): Observable<ConnectResult> {
    const connected = !!token;
    return of({ connected }).pipe(delay(900));
  }

  /**
   * TODO(api): replace with a real multipart/form-data POST to /Scan/Upload
   */
  uploadQrImage(file: File): Observable<ScanUploadResult> {
    if (!file) {
      return of({ success: false, qrText: '', message: 'No file selected.' });
    }
    return of({ success: true, qrText: 'mock-pair-token-from-image' }).pipe(delay(700));
  }

  /** Renders a small placeholder "QR-like" SVG so the UI has something real to show without a backend. */
  private buildPlaceholderQrDataUrl(seed: string): string {
    let hash = 0;
    for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;

    const size = 9;
    let cells = '';
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        hash = (hash * 1103515245 + 12345) >>> 0;
        const on = (hash >> 5) % 3 !== 0;
        if (on) {
          cells += `<rect x="${c * 20}" y="${r * 20}" width="18" height="18" fill="#0a0e22" />`;
        }
      }
    }

    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180">
        <rect width="180" height="180" fill="#ffffff" />
        ${cells}
      </svg>`;

    return 'data:image/svg+xml;base64,' + btoa(svg);
  }
}
