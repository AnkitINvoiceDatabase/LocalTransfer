export interface FileTypeMeta {
  cls: string;
  icon: string;
}

export interface SelectedFile {
  id: number;
  name: string;
  sizeLabel: string;
  sizeBytes: number;
  cls: string;
  icon: string;
  removing?: boolean;
}

export const FILE_TYPE_MAP: Record<string, FileTypeMeta> = {
  pdf: { cls: 'chip-pdf', icon: 'fa-file-pdf' },
  zip: { cls: 'chip-zip', icon: 'fa-file-zipper' },
  rar: { cls: 'chip-zip', icon: 'fa-file-zipper' },
  jpg: { cls: 'chip-img', icon: 'fa-file-image' },
  jpeg: { cls: 'chip-img', icon: 'fa-file-image' },
  png: { cls: 'chip-img', icon: 'fa-file-image' },
  gif: { cls: 'chip-img', icon: 'fa-file-image' },
  mp4: { cls: 'chip-vid', icon: 'fa-file-video' },
  mov: { cls: 'chip-vid', icon: 'fa-file-video' },
  doc: { cls: 'chip-img', icon: 'fa-file-word' },
  docx: { cls: 'chip-img', icon: 'fa-file-word' },
};

export function typeForFileName(name: string): FileTypeMeta {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  return FILE_TYPE_MAP[ext] || { cls: 'chip-img', icon: 'fa-file' };
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}
