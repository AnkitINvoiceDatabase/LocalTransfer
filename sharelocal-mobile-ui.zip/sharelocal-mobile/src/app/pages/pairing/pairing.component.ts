import { CommonModule } from '@angular/common';
import { Component, Signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { PairingService } from '../../core/services/pairing.service';
import { FileTransferService } from '../../core/services/file-transfer.service';
import { RevealDirective } from '../../shared/directives/reveal.directive';
import { QrScannerModalComponent } from '../../shared/qr-scanner-modal/qr-scanner-modal.component';

@Component({
  selector: 'app-pairing',
  standalone: true,
  imports: [CommonModule, RouterLink, RevealDirective, QrScannerModalComponent],
  templateUrl: './pairing.component.html',
  styleUrl: './pairing.component.scss',
})
export class PairingComponent {
  isScannerOpen = false;
  connecting = false;
  connectedDeviceLabel: string | null = null;

  totalCount!: Signal<number>;

  constructor(
    private pairingService: PairingService,
    private fileTransfer: FileTransferService,
    private router: Router
  ) {
    this.totalCount = this.fileTransfer.totalCount;
  }

  openScanner(): void {
    this.isScannerOpen = true;
  }

  onScannerClosed(): void {
    this.isScannerOpen = false;
  }

  onScanned(token: string): void {
    this.isScannerOpen = false;
    this.connecting = true;

    // TODO(api): PairingService.connect() is mocked — swap in the real
    // POST /api/pair/connect call once the .NET API is ready.
    this.pairingService.connect(token).subscribe((result) => {
      this.connecting = false;
      this.connectedDeviceLabel = result.connected ? 'Connected — starting transfer…' : 'Connection failed. Try again.';
    });
  }

  cancel(): void {
    this.router.navigate(['/']);
  }
}
