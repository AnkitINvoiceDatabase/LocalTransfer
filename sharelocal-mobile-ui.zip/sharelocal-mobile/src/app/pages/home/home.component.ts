import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnDestroy, OnInit, Signal, ViewChild } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FileTransferService } from '../../core/services/file-transfer.service';
import { PairingService } from '../../core/services/pairing.service';
import { SelectedFile } from '../../core/models/file-transfer.model';
import { RevealDirective } from '../../shared/directives/reveal.directive';
import { QrScannerModalComponent } from '../../shared/qr-scanner-modal/qr-scanner-modal.component';

interface Device {
  icon: string;
  name: string;
  status: string;
  led: 'led-online' | 'led-idle' | 'led-offline';
  signal: 0 | 2 | 3 | 4;
}

interface Transfer {
  icon: string;
  chipCls: string;
  name: string;
  size: string;
  date: string;
  downloads: number;
  status: 'completed' | 'progress' | 'interrupted';
  statusLabel: string;
  statusIcon: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, RevealDirective, QrScannerModalComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent implements OnInit, OnDestroy {
  // ---------- file upload (delegates state to FileTransferService) ----------
  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;
  isDragOver = false;
  files!: Signal<SelectedFile[]>;
  totalCount!: Signal<number>;
  totalSizeLabel!: Signal<string>;

  // ---------- progress simulation (self-contained demo, as in original design) ----------
  progressPct = 0;
  progressSpeed = '0 MB/s';
  progressTime = '—';
  progressStatus = 'Sending to MacBook Pro — Aman';
  progressComplete = false;
  private readonly TOTAL_MB = 56;
  private progressTimer?: ReturnType<typeof setInterval>;
  private restartTimer?: ReturnType<typeof setTimeout>;

  // ---------- QR connect ----------
  @ViewChild('qrCard') qrCard?: ElementRef<HTMLElement>;
  qrCardTransform = 'rotateY(0) rotateX(0)';
  qrImageUrl: string | null = null;
  qrError: string | null = null;
  isScannerOpen = false;

  // ---------- static content ----------
  devices: Device[] = [
    { icon: 'fa-laptop', name: 'MacBook Pro — Aman', status: 'Connected · this device', led: 'led-online', signal: 4 },
    { icon: 'fa-mobile-screen-button', name: 'iPhone 15 Pro', status: 'Connected · 2 min ago', led: 'led-online', signal: 3 },
    { icon: 'fa-desktop', name: 'Office Desktop', status: 'Idle · 14 min ago', led: 'led-idle', signal: 2 },
    { icon: 'fa-tv', name: 'Living Room TV', status: 'Offline · 1 hr ago', led: 'led-offline', signal: 0 },
  ];

  transfers: Transfer[] = [
    { icon: 'fa-file-pdf', chipCls: 'chip-pdf', name: 'presentation.pdf', size: '24.6 MB', date: 'Jun 16, 2026 · 4:32 PM', downloads: 3, status: 'completed', statusLabel: 'Completed', statusIcon: 'fa-check' },
    { icon: 'fa-file-zipper', chipCls: 'chip-zip', name: 'vacation-photos.zip', size: '142 MB', date: 'Jun 16, 2026 · 2:10 PM', downloads: 1, status: 'completed', statusLabel: 'Completed', statusIcon: 'fa-check' },
    { icon: 'fa-file-zipper', chipCls: 'chip-zip', name: 'design-assets.zip', size: '56 MB', date: 'Jun 17, 2026 · 9:14 AM', downloads: 0, status: 'progress', statusLabel: 'In Progress', statusIcon: 'fa-arrow-up' },
    { icon: 'fa-file-video', chipCls: 'chip-vid', name: 'demo-video.mp4', size: '89.2 MB', date: 'Jun 15, 2026 · 6:48 PM', downloads: 0, status: 'interrupted', statusLabel: 'Interrupted', statusIcon: 'fa-triangle-exclamation' },
    { icon: 'fa-file-word', chipCls: 'chip-img', name: 'quarterly-report.docx', size: '3.1 MB', date: 'Jun 14, 2026 · 11:02 AM', downloads: 5, status: 'completed', statusLabel: 'Completed', statusIcon: 'fa-check' },
  ];

  constructor(
    private fileTransfer: FileTransferService,
    private pairingService: PairingService,
    private router: Router
  ) {
    this.files = this.fileTransfer.files;
    this.totalCount = this.fileTransfer.totalCount;
    this.totalSizeLabel = this.fileTransfer.totalSizeLabel;
  }

  statusBadgeClass(t: Transfer): string {
    return t.status === 'completed' ? 'badge-completed' : t.status === 'progress' ? 'badge-progress' : 'badge-interrupted';
  }

  ngOnInit(): void {
    // seed demo files so the panel isn't empty on first load (matches original design)
    this.fileTransfer.seedDemoFiles([
      { name: 'presentation.pdf', sizeLabel: '24.6 MB', sizeBytes: 24.6 * 1024 * 1024 },
      { name: 'vacation-photos.zip', sizeLabel: '142 MB', sizeBytes: 142 * 1024 * 1024 },
      { name: 'demo-video.mp4', sizeLabel: '89.2 MB', sizeBytes: 89.2 * 1024 * 1024 },
    ]);

    this.progressTimer = setInterval(() => this.tickProgress(), 320);

    // Assumption: QR is generated once when the connect card first renders.
    // TODO(api): PairingService.generateQr() currently returns mock data —
    // see core/services/pairing.service.ts for the real endpoint to wire up.
    this.pairingService.generateQr().subscribe({
      next: (res) => (this.qrImageUrl = res.imageUrl),
      error: () => (this.qrError = 'Could not generate QR code.'),
    });
  }

  ngOnDestroy(): void {
    if (this.progressTimer) clearInterval(this.progressTimer);
    if (this.restartTimer) clearTimeout(this.restartTimer);
  }

  // ---------- file upload ----------
  removeFile(id: number): void {
    this.fileTransfer.removeFile(id);
  }

  onBrowseClick(): void {
    this.fileInputRef.nativeElement.click();
  }

  onDropzoneClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    if (target.classList.contains('dropzone') || target.closest('.drop-icon')) {
      this.fileInputRef.nativeElement.click();
    }
  }

  onFileInputChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.fileTransfer.addFiles(input.files);
    input.value = '';
  }

  onDragEnter(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = true;
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = false;
    if (event.dataTransfer?.files?.length) {
      this.fileTransfer.addFiles(event.dataTransfer.files);
    }
  }

  /**
   * Assumption: "Send Files" takes the user to the pairing/"waiting for
   * receiver" screen (this replaces the original prototype's broken
   * `continueBtn` handler, which referenced an element that didn't exist
   * anywhere in the page).
   */
  onSendFiles(): void {
    if (this.totalCount() === 0) return;
    this.router.navigate(['/pairing']);
  }

  // ---------- progress simulation ----------
  private tickProgress(): void {
    if (this.progressPct >= 100) {
      this.progressComplete = true;
      this.progressPct = 100;
      this.progressStatus = 'Sent to MacBook Pro — Aman';
      this.progressTime = 'Done';
      this.progressSpeed = '—';
      if (this.progressTimer) clearInterval(this.progressTimer);

      this.restartTimer = setTimeout(() => {
        this.progressPct = 0;
        this.progressComplete = false;
        this.progressStatus = 'Sending to MacBook Pro — Aman';
        this.progressTimer = setInterval(() => this.tickProgress(), 320);
      }, 3200);
      return;
    }
    this.progressPct += Math.random() * 7 + 3;
    if (this.progressPct > 100) this.progressPct = 100;
    const speed = 12 + Math.random() * 10;
    this.progressSpeed = speed.toFixed(1) + ' MB/s';
    const remainingMB = this.TOTAL_MB * (1 - this.progressPct / 100);
    const secs = Math.max(1, Math.round(remainingMB / speed));
    this.progressTime = secs + 's';
  }

  get progressPctRounded(): number {
    return Math.round(this.progressPct);
  }

  // ---------- QR card tilt ----------
  onQrCardMouseMove(event: MouseEvent): void {
    const card = this.qrCard?.nativeElement;
    if (!card) return;
    const r = card.getBoundingClientRect();
    const x = (event.clientX - r.left) / r.width - 0.5;
    const y = (event.clientY - r.top) / r.height - 0.5;
    this.qrCardTransform = `rotateY(${x * 10}deg) rotateX(${-y * 10}deg) translateZ(0)`;
  }

  onQrCardMouseLeave(): void {
    this.qrCardTransform = 'rotateY(0) rotateX(0)';
  }

  // ---------- QR scanner modal ----------
  openScanner(): void {
    this.isScannerOpen = true;
  }

  onScannerClosed(): void {
    this.isScannerOpen = false;
  }

  onScanned(token: string): void {
    this.isScannerOpen = false;
    // TODO(api): call PairingService.connect(token) once /api/pair/connect is live.
    this.router.navigate(['/pairing']);
  }
}
