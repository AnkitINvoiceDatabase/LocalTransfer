import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { filter, Subject, takeUntil } from 'rxjs';

interface Particle {
  left: string; top: string; delay: string; duration: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, OnDestroy {
  particles: Particle[] = [];
  activeRoute = '/';
  private destroy$ = new Subject<void>();

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Particles (unchanged)
    for (let i = 0; i < 20; i++) {
      this.particles.push({
        left:     Math.random() * 100 + '%',
        top:      Math.random() * 100 + '%',
        delay:    Math.random() * 6 + 's',
        duration: 4 + Math.random() * 5 + 's',
      });
    }
    // Track active route for bottom-nav highlight (UI only)
    this.router.events.pipe(
      filter(e => e instanceof NavigationEnd),
      takeUntil(this.destroy$)
    ).subscribe((e: any) => {
      this.activeRoute = e.urlAfterRedirects.split('?')[0];
    });
    this.activeRoute = this.router.url.split('?')[0];
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }
}
