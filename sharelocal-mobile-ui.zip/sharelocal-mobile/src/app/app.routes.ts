import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/home/home.component').then((m) => m.HomeComponent),
    title: 'ShareLocal — Instant File Transfer',
  },
  {
    path: 'pairing',
    loadComponent: () => import('./pages/pairing/pairing.component').then((m) => m.PairingComponent),
    title: 'ShareLocal — Waiting for Receiver',
  },
  { path: '**', redirectTo: '' },
];
